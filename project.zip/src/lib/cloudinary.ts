const cloudName = "dvjsh0nb2";
const uploadPreset = "elan_profile_uploads";
const maxFileSize = 5 * 1024 * 1024;
const allowedTypes = new Set([
  "image/avif",
  "image/jpeg",
  "image/png",
  "image/webp",
]);

type CloudinaryUploadResponse = {
  secure_url?: string;
  error?: {
    message?: string;
  };
};

export const uploadImage = async (file: File) => {
  if (!allowedTypes.has(file.type)) {
    throw new Error("Unsupported image format");
  }
  if (file.size > maxFileSize) {
    throw new Error("Image exceeds the 5 MB limit");
  }

  const formData = new FormData();
  formData.append("file", file);
  formData.append("upload_preset", uploadPreset);

  const response = await fetch(
    `https://api.cloudinary.com/v1_1/${cloudName}/image/upload`,
    {
      method: "POST",
      body: formData,
    },
  );
  const result = await response.json() as CloudinaryUploadResponse;

  if (!response.ok || !result.secure_url) {
    throw new Error(result.error?.message || "Cloudinary upload failed");
  }

  return result.secure_url;
};
