import { getApp, getApps, initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyBvaXt5YgXB5SBFNKsxFf-m-WRMCiHV1rM",
  authDomain: "planer-20a24.firebaseapp.com",
  projectId: "planer-20a24",
  storageBucket: "planer-20a24.firebasestorage.app",
  messagingSenderId: "24354921057",
  appId: "1:24354921057:web:bee678818a7dea53b2e820",
  measurementId: "G-G1HPX8TD9J",
};

export const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
