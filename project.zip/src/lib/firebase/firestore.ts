import {
  Timestamp,
  addDoc,
  collection,
  doc,
  getDoc,
  onSnapshot,
  setDoc,
  updateDoc,
  writeBatch,
  type DocumentData,
  type Unsubscribe,
} from "firebase/firestore";
import { db } from "./firebase";

export type IntervalUnit = "days" | "weeks" | "months" | "years";

export interface RoutineSchedule {
  name: string;
  intervalValue: number;
  intervalUnit: IntervalUnit;
}

export type NewRoutine = RoutineSchedule & DocumentData;

export type EntryKind = "task" | "work" | "beauty";

export interface PlannerEntry {
  id: string;
  kind: EntryKind;
  title: string;
  date: string;
  startTime: string;
  durationMinutes: number | null;
  icon: string;
  amount: number;
  completed: boolean;
  workType?: "permanent" | "day" | "vacation" | "sick";
  hours?: number;
  lunchFrom?: string;
  lunchTo?: string;
  hourlyRate?: number;
  periodFrom?: string;
  periodTo?: string;
  documentUrl?: string;
}

export type NewPlannerEntry = Omit<PlannerEntry, "id" | "completed">;

export interface UserPreferences {
  lang: "ru" | "en";
  accent: string;
  currency: string;
  firstName: string;
  navImage: string;
  miniPhoto: string;
  profileImage: string;
}

export const verifyFirestoreAvailability = (userId: string) =>
  getDoc(doc(db, "users", userId));

export const subscribeToEntries = (
  userId: string,
  callback: (entries: PlannerEntry[]) => void,
  onError?: (error: Error) => void,
): Unsubscribe => onSnapshot(
  collection(db, "users", userId, "entries"),
  (snapshot) => {
    const entries = snapshot.docs.map((entryDoc) => ({
      id: entryDoc.id,
      ...entryDoc.data(),
    })) as PlannerEntry[];

    entries.sort((first, second) =>
      `${first.date}-${first.startTime}`.localeCompare(`${second.date}-${second.startTime}`),
    );
    callback(entries);
  },
  onError,
);

export const addPlannerEntry = (userId: string, entry: NewPlannerEntry) =>
  addDoc(collection(db, "users", userId, "entries"), {
    ...entry,
    completed: false,
    createdAt: Timestamp.now(),
    updatedAt: Timestamp.now(),
  });

export const setEntryCompleted = (
  userId: string,
  entryId: string,
  completed: boolean,
) => updateDoc(doc(db, "users", userId, "entries", entryId), {
  completed,
  updatedAt: Timestamp.now(),
});

export const subscribeToUserPreferences = (
  userId: string,
  callback: (preferences: Partial<UserPreferences>) => void,
  onError?: (error: Error) => void,
): Unsubscribe => onSnapshot(
  doc(db, "users", userId),
  (snapshot) => callback(snapshot.exists() ? snapshot.data() as Partial<UserPreferences> : {}),
  onError,
);

export const saveUserPreferences = (
  userId: string,
  preferences: UserPreferences,
) => setDoc(doc(db, "users", userId), {
  ...preferences,
  updatedAt: Timestamp.now(),
}, { merge: true });

export const createRoutine = (userId: string, routine: NewRoutine) => {
  const now = Timestamp.now();

  return addDoc(collection(db, "users", userId, "routines"), {
    ...routine,
    createdAt: now,
    updatedAt: now,
  });
};

export const completeRoutine = async (
  userId: string,
  routineId: string,
  currentRoutine: RoutineSchedule,
) => {
  const completedAt = new Date();
  const nextDueAt = calculateNextDue(
    completedAt,
    currentRoutine.intervalValue,
    currentRoutine.intervalUnit,
  );
  const routineRef = doc(db, "users", userId, "routines", routineId);
  const historyRef = doc(collection(db, "users", userId, "history"));
  const batch = writeBatch(db);

  batch.update(routineRef, {
    lastCompletedAt: Timestamp.fromDate(completedAt),
    nextDueAt: Timestamp.fromDate(nextDueAt),
    updatedAt: Timestamp.now(),
  });
  batch.set(historyRef, {
    routineId,
    routineName: currentRoutine.name,
    completedAt: Timestamp.fromDate(completedAt),
  });

  await batch.commit();
};

export function calculateNextDue(date: Date, value: number, unit: IntervalUnit) {
  const nextDate = new Date(date);

  if (unit === "days") nextDate.setDate(nextDate.getDate() + value);
  if (unit === "weeks") nextDate.setDate(nextDate.getDate() + value * 7);
  if (unit === "months") nextDate.setMonth(nextDate.getMonth() + value);
  if (unit === "years") nextDate.setFullYear(nextDate.getFullYear() + value);

  return nextDate;
}
