import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut,
  type User,
} from "firebase/auth";
import { auth } from "./firebase";

const nicknamePattern = /^[a-zA-Z0-9_]{3,20}$/;

export class InvalidNicknameError extends Error {
  constructor() {
    super("Nickname must contain 3–20 Latin letters, numbers, or underscores.");
    this.name = "InvalidNicknameError";
  }
}

export const normalizeNickname = (nickname: string) => nickname.trim().toLowerCase();

export const getTechnicalEmail = (nickname: string) => {
  const normalizedNickname = normalizeNickname(nickname);

  if (!nicknamePattern.test(normalizedNickname)) {
    throw new InvalidNicknameError();
  }

  return `${normalizedNickname}@planner.local`;
};

export const signUpWithNickname = (nickname: string, password: string) =>
  createUserWithEmailAndPassword(
    auth,
    getTechnicalEmail(nickname),
    password,
  );

export const loginWithNickname = (nickname: string, password: string) =>
  signInWithEmailAndPassword(
    auth,
    getTechnicalEmail(nickname),
    password,
  );

export const logoutUser = () => signOut(auth);

export const listenToAuth = (callback: (user: User | null) => void) =>
  onAuthStateChanged(auth, callback);
