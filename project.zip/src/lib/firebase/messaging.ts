import { deleteDoc, doc, serverTimestamp, setDoc } from "firebase/firestore";
import {
  deleteToken,
  getMessaging,
  getToken,
  isSupported,
  onMessage,
  type MessagePayload,
} from "firebase/messaging";
import { app, db } from "./firebase";

const vapidKey = "BH6ICo-435TYEZmVTSvJfH-MMJroHqx6aBUy8J2PXYQl0r7jajkGlJpBEk4VIS39lW4kMypUoQRVKDCj86thmDg";
const tokenStorageKey = (userId: string) => `elan-push-token:${userId}`;

export type PushState = "blocked" | "disabled" | "enabled" | "loading" | "unsupported";

const getTokenId = async (token: string) => {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(token));
  return Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("");
};

export const getPushState = async (userId: string): Promise<PushState> => {
  if (!("Notification" in window) || !("serviceWorker" in navigator) || !await isSupported()) {
    return "unsupported";
  }
  if (Notification.permission === "denied") return "blocked";
  return localStorage.getItem(tokenStorageKey(userId)) ? "enabled" : "disabled";
};

export const enablePushNotifications = async (userId: string) => {
  if (!await isSupported()) throw new Error("Push notifications are not supported");
  const permission = await Notification.requestPermission();
  if (permission !== "granted") throw new Error("Notification permission was not granted");

  const serviceWorkerRegistration = await navigator.serviceWorker.register(
    "/firebase-messaging-sw.js",
    { scope: "/" },
  );
  const messaging = getMessaging(app);
  const token = await getToken(messaging, {
    vapidKey,
    serviceWorkerRegistration,
  });
  if (!token) throw new Error("FCM did not return a token");

  const tokenId = await getTokenId(token);
  await setDoc(doc(db, "users", userId, "pushTokens", tokenId), {
    token,
    enabled: true,
    platform: "web",
    userAgent: navigator.userAgent,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  }, { merge: true });
  localStorage.setItem(tokenStorageKey(userId), token);
  return token;
};

export const disablePushNotifications = async (userId: string) => {
  const storedToken = localStorage.getItem(tokenStorageKey(userId));
  const messaging = getMessaging(app);

  try {
    await deleteToken(messaging);
    if (storedToken) {
      const tokenId = await getTokenId(storedToken);
      await deleteDoc(doc(db, "users", userId, "pushTokens", tokenId));
    }
  } finally {
    localStorage.removeItem(tokenStorageKey(userId));
  }
};

export const listenToForegroundMessages = async (
  callback: (payload: MessagePayload) => void,
) => {
  if (!await isSupported()) return () => undefined;
  return onMessage(getMessaging(app), callback);
};
