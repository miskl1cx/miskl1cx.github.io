import { CSSProperties, FormEvent, ReactNode, useEffect, useState } from "react";
import type { User } from "firebase/auth";
import { InvalidNicknameError, listenToAuth, loginWithNickname, logoutUser, signUpWithNickname } from "./lib/firebase/auth";
import {
  disablePushNotifications,
  enablePushNotifications,
  getPushState,
  listenToForegroundMessages,
  type PushState,
} from "./lib/firebase/messaging";
import {
  addPlannerEntry,
  saveUserPreferences,
  setEntryCompleted,
  subscribeToEntries,
  subscribeToUserPreferences,
  verifyFirestoreAvailability,
  type EntryKind,
  type NewPlannerEntry,
  type PlannerEntry,
} from "./lib/firebase/firestore";
import { uploadImage } from "./lib/cloudinary";

type Lang = "ru" | "en";
type IconName = "home" | "sparkle" | "briefcase" | "user" | "settings" | "plus" | "clock" | "wallet" | "check" | "bell" | "close" | "camera" | "coffee" | "heart" | "calendar";

const Icon = ({ name, size = 20 }: { name: IconName; size?: number }) => {
  const paths: Record<IconName, ReactNode> = {
    home: <><path d="m3 11 9-8 9 8" /><path d="M5 10v10h14V10M9 20v-6h6v6" /></>,
    sparkle: <><path d="M12 3c.5 4.6 2.4 6.5 7 7-4.6.5-6.5 2.4-7 7-.5-4.6-2.4-6.5-7-7 4.6-.5 6.5-2.4 7-7Z" /><path d="M19 16v5M16.5 18.5h5" /></>,
    briefcase: <><rect x="3" y="7" width="18" height="13" rx="3" /><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M3 12h18M10 12v2h4v-2" /></>,
    user: <><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></>,
    settings: <><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3A1.7 1.7 0 0 0 10 3v-.2h4V3a1.7 1.7 0 0 0 1.6 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z" /></>,
    plus: <path d="M12 5v14M5 12h14" />,
    clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
    wallet: <><path d="M4 6h14a2 2 0 0 1 2 2v11H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h12" /><path d="M15 11h7v5h-7a2 2 0 0 1 0-5Z" /></>,
    check: <path d="m5 12 4 4L19 6" />,
    bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9ZM10 21h4" /></>,
    close: <path d="M6 6l12 12M18 6 6 18" />,
    camera: <><path d="M5 7h3l1.5-2h5L16 7h3a2 2 0 0 1 2 2v9H3V9a2 2 0 0 1 2-2Z" /><circle cx="12" cy="12.5" r="3.5" /></>,
    coffee: <><path d="M4 8h12v6a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5V8Z" /><path d="M16 10h2a3 3 0 0 1 0 6h-3M7 3v2M11 3v2" /></>,
    heart: <path d="M20.8 4.6a5.4 5.4 0 0 0-7.6 0L12 5.8l-1.2-1.2a5.4 5.4 0 0 0-7.6 7.6L12 21l8.8-8.8a5.4 5.4 0 0 0 0-7.6Z" />,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="3" /><path d="M8 3v4M16 3v4M3 10h18" /><path d="M8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01" /></>,
  };
  return <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">{paths[name]}</svg>;
};

const Button = ({ children, className = "", onClick, type = "button", ariaLabel, style, disabled = false }: {
  children: ReactNode; className?: string; onClick?: () => void; type?: "button" | "submit"; ariaLabel?: string; style?: CSSProperties; disabled?: boolean;
}) => <button type={type} className={className} onClick={onClick} aria-label={ariaLabel} style={style} disabled={disabled}>{children}</button>;

const Field = ({ label, type = "text", placeholder, required = false, value, onChange, pattern, minLength }: {
  label: string; type?: string; placeholder?: string; required?: boolean; value?: string; onChange?: (value: string) => void; pattern?: string; minLength?: number;
}) => <label className="field"><span>{label}</span><input type={type} placeholder={placeholder} required={required} value={value} pattern={pattern} minLength={minLength} onChange={(event) => onChange?.(event.target.value)} /></label>;

const dictionaries = {
  ru: {
    email: "Никнейм", password: "Пароль", repeatPassword: "Повторите пароль", minChars: "Минимум 8 символов", repeat: "Еще раз",
    login: "Войти", create: "Создать аккаунт", noAccount: "Нет аккаунта?", hasAccount: "Уже есть аккаунт?", register: "Регистрация", enter: "Вход",
    overview: "Обзор", statistics: "Статистика", month: "Май", year: "2025", nearest: "БЛИЖАЙШАЯ ПРОЦЕДУРА",
    hair: "Уход за волосами", todayAt: "Сегодня в 19:30 · Салон MONE", inHours: "через 8 часов", today: "Сегодня", events: "3 события",
    morning: "Утренняя рутина", care: "Уход · 20 минут", meeting: "Встреча с командой", workZoom: "Работа · Zoom", pilates: "Пилатес", movement: "Движение · Студия",
    expenses: "Расходы", income: "Доход", procedures: "Бьюти-процедуры", oneMonth: "1 мес.", twoMonths: "2 мес.", sixMonths: "6 мес.", oneYear: "1 год",
    schedule: "Расписание", progress: "Прогресс", dayPlan: "План на день", workday: "Рабочий день", hours: "8 часов", items: "3 пункта", perDay: "за день",
    newEntry: "Новая запись", addWork: "Добавить рабочий день", createProcedure: "Создать процедуру", close: "Закрыть",
    permanent: "Постоянная", oneDay: "Один день", vacation: "Отпуск", sick: "Больничный", title: "Название", reason: "Причина",
    exampleWork: "Например, Élan Studio", exampleBeauty: "Например, уход за лицом", frequency: "Периодичность", days: "Количество дней", cost: "Стоимость процедуры",
    weeklyHours: "Часов в неделю", lunchFrom: "Обед с", lunchTo: "Обед до", monthlySalary: "Зарплата в месяц", hoursAmount: "Количество часов", hourlyRate: "Ставка за час",
    period: "Период", periodFrom: "Период с", periodTo: "Период по", vacationIncome: "Доход за отпуск", addPhoto: "Добавить фото", document: "Справка или документ", save: "Сохранить",
    proceduresMetric: "процедур", rhythmDays: "дней в ритме", balance: "баланс",
    personalization: "Персонализация", settings: "Настройки",
    language: "Язык приложения", accent: "Акцентный цвет", accentHelp: "Введите HEX-код цвета", navPhoto: "Фото на навигации", navHelp: "Выберите изображение из галереи",
    choosePhoto: "Выбрать фото", beautyLabel: "Бьюти", workLabel: "Работа", homeLabel: "Главная", profileLabel: "Профиль",
    currency: "Валюта", firstName: "Имя", miniPhoto: "Мини-фото", miniPhotoHelp: "Фото возле имени", profilePhoto: "Фото профиля", profilePhotoHelp: "Большое фото на фоне профиля", darker: "Темнее", lighter: "Светлее", logout: "Выйти из аккаунта", notifications: "Уведомления", pushEnabled: "Push-уведомления включены", pushDisabled: "Получайте напоминания о записях", pushBlocked: "Уведомления запрещены в браузере", pushUnsupported: "Push не поддерживается на этом устройстве", enable: "Включить", disable: "Выключить", pushFailed: "Не удалось изменить настройки уведомлений.",
    weekdays: ["ПН","ВТ","СР","ЧТ","ПТ","СБ","ВС"], dateLabel: "17 МАЯ · СРЕДА",
    passwordMismatch: "Пароли не совпадают", authFailed: "Не удалось выполнить вход. Проверьте данные и попробуйте снова.", loading: "Загрузка",
    nicknamePlaceholder: "например, elan_user", nicknameInvalid: "Используйте 3–20 латинских букв, цифр или _", nicknameTaken: "Этот никнейм уже занят", invalidCredentials: "Неверный никнейм или пароль", authUnavailable: "Включите Email/Password в Firebase Authentication",
    authNotConfigured: "Firebase Authentication не настроен. Включите способ входа Email/Password в Firebase Console.", authNetworkError: "Нет соединения с Firebase. Проверьте сеть и ограничения API-ключа.", weakPassword: "Пароль не соответствует требованиям безопасности Firebase.", tooManyRequests: "Слишком много попыток. Попробуйте позже.",
    task: "Задача", addTask: "Добавить задачу", date: "Дата", startTime: "Время начала", duration: "Длительность, минут", icon: "Иконка", amount: "Сумма", noEntries: "На этот день ничего не запланировано", noStatistics: "Статистика появится после добавления записей", saveFailed: "Не удалось сохранить. Проверьте подключение к Firebase.", databaseUnavailable: "Создайте базу Firestore с ID (default) в Firebase Console, затем обновите страницу.", rulesUnavailable: "Доступ к Firestore закрыт. Задеплойте firestore.rules и обновите страницу.", photoUploadFailed: "Не удалось загрузить фото. Используйте JPG, PNG, WebP или AVIF размером до 5 МБ.", minutesShort: "мин",
  },
  en: {
    email: "Nickname", password: "Password", repeatPassword: "Confirm password", minChars: "At least 8 characters", repeat: "Enter again",
    login: "Sign in", create: "Create account", noAccount: "No account?", hasAccount: "Already have an account?", register: "Register", enter: "Sign in",
    overview: "Overview", statistics: "Statistics", month: "May", year: "2025", nearest: "UPCOMING APPOINTMENT",
    hair: "Hair treatment", todayAt: "Today at 7:30 PM · MONE salon", inHours: "in 8 hours", today: "Today", events: "3 events",
    morning: "Morning routine", care: "Care · 20 minutes", meeting: "Team meeting", workZoom: "Work · Zoom", pilates: "Pilates", movement: "Movement · Studio",
    expenses: "Expenses", income: "Income", procedures: "Beauty treatments", oneMonth: "1 mo.", twoMonths: "2 mo.", sixMonths: "6 mo.", oneYear: "1 year",
    schedule: "Schedule", progress: "Progress", dayPlan: "Day plan", workday: "Workday", hours: "8 hours", items: "3 items", perDay: "per day",
    newEntry: "NEW ENTRY", addWork: "Add workday", createProcedure: "Create treatment", close: "Close",
    permanent: "Permanent", oneDay: "One day", vacation: "Vacation", sick: "Sick leave", title: "Title", reason: "Reason",
    exampleWork: "For example, Élan Studio", exampleBeauty: "For example, face care", frequency: "Frequency", days: "Number of days", cost: "Treatment cost",
    weeklyHours: "Hours per week", lunchFrom: "Lunch from", lunchTo: "Lunch to", monthlySalary: "Monthly salary", hoursAmount: "Number of hours", hourlyRate: "Hourly rate",
    period: "Period", periodFrom: "Period from", periodTo: "Period to", vacationIncome: "Vacation income", addPhoto: "Add photo", document: "Certificate or document", save: "Save",
    proceduresMetric: "treatments", rhythmDays: "days in rhythm", balance: "balance",
    personalization: "PERSONALIZATION", settings: "Settings",
    language: "App language", accent: "Accent color", accentHelp: "Enter a HEX color", navPhoto: "Navigation photo", navHelp: "Choose an image from your gallery",
    choosePhoto: "Choose photo", beautyLabel: "Beauty", workLabel: "Work", homeLabel: "Home", profileLabel: "Profile",
    currency: "Currency", firstName: "First name", miniPhoto: "Mini photo", miniPhotoHelp: "Photo next to your name", profilePhoto: "Profile photo", profilePhotoHelp: "Large profile background photo", darker: "Darker", lighter: "Lighter", logout: "Sign out", notifications: "Notifications", pushEnabled: "Push notifications are enabled", pushDisabled: "Receive reminders about your entries", pushBlocked: "Notifications are blocked in the browser", pushUnsupported: "Push is not supported on this device", enable: "Enable", disable: "Disable", pushFailed: "Could not change notification settings.",
    weekdays: ["MON","TUE","WED","THU","FRI","SAT","SUN"], dateLabel: "MAY 17 · WEDNESDAY",
    passwordMismatch: "Passwords do not match", authFailed: "Unable to sign in. Check your details and try again.", loading: "Loading",
    nicknamePlaceholder: "for example, elan_user", nicknameInvalid: "Use 3–20 Latin letters, numbers, or _", nicknameTaken: "This nickname is already taken", invalidCredentials: "Incorrect nickname or password", authUnavailable: "Enable Email/Password in Firebase Authentication",
    authNotConfigured: "Firebase Authentication is not configured. Enable the Email/Password provider in Firebase Console.", authNetworkError: "Cannot connect to Firebase. Check the network and API key restrictions.", weakPassword: "The password does not meet the Firebase security requirements.", tooManyRequests: "Too many attempts. Try again later.",
    task: "Task", addTask: "Add task", date: "Date", startTime: "Start time", duration: "Duration, minutes", icon: "Icon", amount: "Amount", noEntries: "Nothing is planned for this day", noStatistics: "Statistics will appear after you add entries", saveFailed: "Could not save. Check the Firebase connection.", databaseUnavailable: "Create a Firestore database with ID (default) in Firebase Console, then reload the page.", rulesUnavailable: "Firestore access is denied. Deploy firestore.rules and reload the page.", photoUploadFailed: "Could not upload the photo. Use JPG, PNG, WebP, or AVIF up to 5 MB.", minutesShort: "min",
  },
};

type Copy = typeof dictionaries.ru;

function getAuthErrorMessage(error: unknown, t: Copy) {
  if (error instanceof InvalidNicknameError) return t.nicknameInvalid;

  const code = typeof error === "object" && error !== null && "code" in error
    ? String(error.code)
    : "";

  if (code === "auth/email-already-in-use") return t.nicknameTaken;
  if (["auth/invalid-credential", "auth/user-not-found", "auth/wrong-password"].includes(code)) return t.invalidCredentials;
  if (code === "auth/operation-not-allowed") return t.authUnavailable;
  if (code === "auth/configuration-not-found") return t.authNotConfigured;
  if (["auth/network-request-failed", "auth/app-not-authorized", "auth/invalid-api-key", "auth/unauthorized-domain"].includes(code)) return t.authNetworkError;
  if (["auth/weak-password", "auth/password-does-not-meet-requirements"].includes(code)) return t.weakPassword;
  if (code === "auth/too-many-requests") return t.tooManyRequests;

  return code ? `${t.authFailed} (${code})` : t.authFailed;
}

function LanguageToggle({ lang, setLang, dark = false }: { lang: Lang; setLang: (lang: Lang) => void; dark?: boolean }) {
  return <div className={`language-toggle ${dark ? "dark" : ""}`}>
    <Button className={lang === "ru" ? "active" : ""} onClick={() => setLang("ru")}>RU</Button>
    <Button className={lang === "en" ? "active" : ""} onClick={() => setLang("en")}>EN</Button>
  </div>;
}

function Auth({ onAuthenticate, lang, setLang }: {
  onAuthenticate: (mode: "login" | "register", email: string, password: string) => Promise<void>;
  lang: Lang;
  setLang: (lang: Lang) => void;
}) {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [nickname, setNickname] = useState("");
  const [password, setPassword] = useState("");
  const [repeatedPassword, setRepeatedPassword] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const t = dictionaries[lang];
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setError("");

    if (mode === "register" && password !== repeatedPassword) {
      setError(t.passwordMismatch);
      return;
    }

    setSubmitting(true);
    try {
      await onAuthenticate(mode, nickname, password);
    } catch (authError) {
      setError(getAuthErrorMessage(authError, t));
    } finally {
      setSubmitting(false);
    }
  };
  const changeMode = () => {
    setMode(mode === "login" ? "register" : "login");
    setError("");
    setRepeatedPassword("");
  };
  return <main className="auth-shell">
    <LanguageToggle lang={lang} setLang={setLang} dark />
    <section className="auth-card">
      <form onSubmit={submit} className="auth-form">
        <Field label={t.email} placeholder={t.nicknamePlaceholder} required value={nickname} pattern="[A-Za-z0-9_]{3,20}" onChange={setNickname} />
        <Field label={t.password} type="password" placeholder={t.minChars} required value={password} minLength={mode === "register" ? 8 : undefined} onChange={setPassword} />
        {mode === "register" && <Field label={t.repeatPassword} type="password" placeholder={t.repeat} required value={repeatedPassword} minLength={8} onChange={setRepeatedPassword} />}
        {error && <p className="auth-error" role="alert">{error}</p>}
        <Button type="submit" className="primary-button" disabled={submitting}>{submitting ? `${t.loading}…` : mode === "login" ? t.login : t.create}</Button>
      </form>
      <div className="auth-mode-link">
        <span>{mode === "login" ? t.noAccount : t.hasAccount}</span>
        <Button onClick={changeMode} disabled={submitting}>{mode === "login" ? t.register : t.enter}</Button>
      </div>
    </section>
  </main>;
}

function toDateKey(date: Date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function getWeekDates(date: Date) {
  const monday = new Date(date);
  const day = monday.getDay() || 7;
  monday.setDate(monday.getDate() - day + 1);
  return Array.from({ length: 7 }, (_, index) => {
    const result = new Date(monday);
    result.setDate(monday.getDate() + index);
    return result;
  });
}

function getMonthGridDates(date: Date) {
  const firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
  const lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);
  const gridStart = getWeekDates(firstDay)[0];
  const gridEndWeek = getWeekDates(lastDay);
  const gridEnd = gridEndWeek[6];
  const dates: Date[] = [];

  if (!gridStart || !gridEnd) return dates;
  const cursor = new Date(gridStart);
  while (cursor <= gridEnd) {
    dates.push(new Date(cursor));
    cursor.setDate(cursor.getDate() + 1);
  }
  return dates;
}

function getMonthName(date: Date, lang: Lang) {
  const month = new Intl.DateTimeFormat(lang === "ru" ? "ru-RU" : "en-US", { month: "long" }).format(date);
  return month.charAt(0).toUpperCase() + month.slice(1);
}

function getCurrencySymbol(currency: string) {
  if (currency === "USD") return "$";
  if (currency === "EUR") return "€";
  if (currency === "BYN") return "Br";
  return "₽";
}

const calendarTones = ["coral-event", "blue-event", "sage-event", "yellow-event", "violet-event"];
const selectableIcons: IconName[] = ["check", "clock", "sparkle", "briefcase", "heart", "coffee", "wallet"];

function WeekStrip({ t, dates, selectedDate, onSelect }: { t: Copy; dates: Date[]; selectedDate: string; onSelect: (date: string) => void }) {
  return <div className="week-strip">{dates.map((date, index) => {
    const dateKey = toDateKey(date);
    return <Button key={dateKey} onClick={() => onSelect(dateKey)} className={dateKey === selectedDate ? "day active" : "day"}><span>{t.weekdays[index]}</span><strong>{date.getDate()}</strong>{dateKey === selectedDate && <i />}</Button>;
  })}</div>;
}

function TaskList({ entries, t, onToggle }: { entries: PlannerEntry[]; t: Copy; onToggle: (entry: PlannerEntry) => void }) {
  return <div className="task-list">{entries.map((entry) => {
    const tone = entry.kind === "work" ? "mint" : entry.kind === "beauty" ? "lilac" : "peach";
    const kindLabel = entry.kind === "work" ? t.workLabel : entry.kind === "beauty" ? t.beautyLabel : t.task;
    const duration = entry.durationMinutes ? ` · ${entry.durationMinutes} ${t.minutesShort}` : "";
    return <div className={`task-row task-${tone}`} key={entry.id}>
      <div className={`task-icon ${tone}`}><Icon name={entry.icon as IconName} size={18} /></div>
      <div className="task-text"><small>{entry.startTime || "—"}</small><strong>{entry.title}</strong><span>{kindLabel}{duration}</span></div>
      <Button className={`round-check ${entry.completed ? "done" : ""}`} onClick={() => onToggle(entry)} ariaLabel={entry.title}>{entry.completed && <Icon name="check" size={14} />}</Button>
    </div>;
  })}</div>;
}

function SectionHeader({ title, action }: { title: string; action?: ReactNode }) {
  return <div className="section-header"><h2>{title}</h2>{action}</div>;
}

function EmptyState({ children }: { children: ReactNode }) {
  return <div className="empty-state"><Icon name="clock" size={22} /><span>{children}</span></div>;
}

function Home({ t, lang, currency, entries = [], onCreate, onToggle }: {
  t: Copy; lang: Lang; currency: string; entries: PlannerEntry[]; onCreate: () => void; onToggle: (entry: PlannerEntry) => void;
}) {
  const today = new Date();
  const [period, setPeriod] = useState(t.oneYear);
  const [tab, setTab] = useState<"overview" | "stats">("overview");
  const [selectedDate, setSelectedDate] = useState(toDateKey(today));
  const weekDates = getWeekDates(today);
  const selectedEntries = entries.filter((entry) => entry.date === selectedDate);
  const monthEntries = entries.filter((entry) => {
    const date = new Date(`${entry.date}T00:00:00`);
    return date.getMonth() === today.getMonth() && date.getFullYear() === today.getFullYear();
  });
  const upcoming = entries.find((entry) => entry.date >= toDateKey(today) && !entry.completed);
  const symbol = getCurrencySymbol(currency);
  return <div className="page home-page">
    <Button className="icon-button home-notification" ariaLabel="Notifications"><Icon name="bell" /></Button>
    <div className="subtabs centered-tabs home-tabs">
      <Button className={tab === "overview" ? "active" : ""} onClick={() => setTab("overview")}>{t.overview}</Button>
      <Button className={tab === "stats" ? "active" : ""} onClick={() => setTab("stats")}>{t.statistics}</Button>
    </div>
    <header className="month-home-title"><h1>{getMonthName(today, lang)}</h1><span>{today.getFullYear()}</span></header>
    {tab === "overview" ? <>
      <WeekStrip t={t} dates={weekDates} selectedDate={selectedDate} onSelect={setSelectedDate} />
      {upcoming && <section className="hero-card">
        <div className="hero-top"><span className="soft-icon"><Icon name={upcoming.icon as IconName} /></span><span>{t.nearest}</span></div>
        <h2>{upcoming.title}</h2><p>{upcoming.date}{upcoming.startTime ? ` · ${upcoming.startTime}` : ""}</p>
      </section>}
      <section><SectionHeader title={new Intl.DateTimeFormat(lang === "ru" ? "ru-RU" : "en-US", { day: "numeric", month: "long" }).format(new Date(`${selectedDate}T00:00:00`))} action={<span className="count-pill">{selectedEntries.length}</span>} />{selectedEntries.length ? <TaskList entries={selectedEntries} t={t} onToggle={onToggle} /> : <EmptyState>{t.noEntries}</EmptyState>}</section>
    </> : <Stats t={t} period={period} setPeriod={setPeriod} symbol={symbol} entries={monthEntries} />}
    <Button className="fab" onClick={onCreate} ariaLabel={t.addTask}><Icon name="plus" size={26} /></Button>
  </div>;
}

function Stats({ t, period, setPeriod, symbol, entries = [] }: { t: Copy; period: string; setPeriod: (p: string) => void; symbol: string; entries: PlannerEntry[] }) {
  const periods = [t.oneMonth, t.twoMonths, t.sixMonths, t.oneYear];
  if (!entries.length) return <section className="stats-section"><EmptyState>{t.noStatistics}</EmptyState></section>;
  const expenses = entries.filter((entry) => entry.kind === "beauty").reduce((sum, entry) => sum + entry.amount, 0);
  const income = entries.filter((entry) => entry.kind === "work").reduce((sum, entry) => sum + entry.amount, 0);
  const procedures = entries.filter((entry) => entry.kind === "beauty").length;
  const charts = [
    { title: t.expenses, value: `${expenses.toLocaleString()} ${symbol}`, bars: entries.slice(-7).map((entry) => Math.max(20, Math.min(100, entry.amount / 10 || 32))), tone: "purple" },
    { title: t.income, value: `${income.toLocaleString()} ${symbol}`, bars: entries.slice(-7).map((entry) => Math.max(20, Math.min(100, entry.amount / 10 || 32))), tone: "green" },
    { title: t.procedures, value: String(procedures), bars: entries.slice(-7).map((_, index) => 30 + index * 8), tone: "orange" },
  ];
  return <section className="stats-section">
    <div className="periods">{periods.map((item) => <Button key={item} className={period === item ? "active" : ""} onClick={() => setPeriod(item)}>{item}</Button>)}</div>
    {charts.map((chart) => <article className={`chart-card ${chart.tone}`} key={chart.title}>
      <div className="chart-head"><div><span>{chart.title}</span><strong>{chart.value}</strong></div></div>
      <div className="bars">{chart.bars.map((height, index) => <i key={index} style={{ height: `${height}%` }} />)}</div>
    </article>)}
  </section>;
}

function TimelineCalendar({ t, dates, entries = [], selectedDate, onSelect }: {
  t: Copy; dates: Date[]; entries: PlannerEntry[]; selectedDate: string; onSelect: (date: string) => void;
}) {
  return <div className="timeline-calendar">
    <div className="timeline-head">{dates.map((date, index) => {
      const dateKey = toDateKey(date);
      return <Button key={dateKey} className={selectedDate === dateKey ? "selected" : ""} onClick={() => onSelect(dateKey)}><span>{t.weekdays[index]}</span><strong>{date.getDate()}</strong></Button>;
    })}</div>
    <div className="timeline-columns">{dates.map((date, column) => {
      const dateKey = toDateKey(date);
      const dayEntries = entries.filter((entry) => entry.date === dateKey);
      return <div className="timeline-column" key={dateKey}>{dayEntries.map((entry, row) => {
        const hasTime = Boolean(entry.startTime);
        const height = hasTime ? Math.max(42, Math.min(150, 34 + (entry.durationMinutes ?? 30) / 2)) : 34;
        return <Button className={`calendar-event ${calendarTones[(column + row) % calendarTones.length]} ${hasTime ? "" : "no-time"}`} style={{ height: `${height}px` } as CSSProperties} key={entry.id} onClick={() => onSelect(dateKey)} ariaLabel={entry.title}><Icon name={entry.icon as IconName} size={16} /></Button>;
      })}</div>;
    })}</div>
  </div>;
}

function MonthPicker({ t, monthDate, entries, selectedDate, onSelect }: {
  t: Copy; monthDate: Date; entries: PlannerEntry[]; selectedDate: string; onSelect: (date: string) => void;
}) {
  const dates = getMonthGridDates(monthDate);
  return <div className="month-picker">
    <div className="month-picker-head">{t.weekdays.map((weekday) => <span key={weekday}>{weekday}</span>)}</div>
    <div className="month-picker-grid">{dates.map((date) => {
      const dateKey = toDateKey(date);
      const count = entries.filter((entry) => entry.date === dateKey).length;
      const outside = date.getMonth() !== monthDate.getMonth();
      return <Button key={dateKey} className={`${selectedDate === dateKey ? "selected" : ""} ${outside ? "outside" : ""}`} onClick={() => onSelect(dateKey)}><strong>{date.getDate()}</strong>{count > 0 && <i>{count}</i>}</Button>;
    })}</div>
  </div>;
}

function Tracker({ type, onCreate, t, lang, currency, entries = [], onToggle }: {
  type: "beauty" | "work"; onCreate: () => void; t: Copy; lang: Lang; currency: string; entries: PlannerEntry[]; onToggle: (entry: PlannerEntry) => void;
}) {
  const today = new Date();
  const [tab, setTab] = useState("month");
  const [selectedDate, setSelectedDate] = useState(toDateKey(today));
  const [monthOpen, setMonthOpen] = useState(false);
  const filteredEntries = entries.filter((entry) => entry.kind === type);
  const selectedEntries = filteredEntries.filter((entry) => entry.date === selectedDate);
  const selectedDateValue = new Date(`${selectedDate}T00:00:00`);
  const weekDates = getWeekDates(selectedDateValue);
  const symbol = getCurrencySymbol(currency);
  const work = type === "work";
  const tabs = work ? [["month", getMonthName(selectedDateValue, lang)], ["schedule", t.schedule], ["income", t.income]] : [["month", getMonthName(selectedDateValue, lang)], ["procedures", t.procedures], ["progress", t.progress]];
  return <div className="page tracker-page">
    <div className="subtabs centered-tabs tracker-tabs">{tabs.map(([id, label]) => <Button key={id} className={tab === id ? "active" : ""} onClick={() => setTab(id)}>{label}</Button>)}</div>
    {tab === "month" ? <>
      <section className="calendar-section">
        <div className="month-title centered"><span>{selectedDateValue.getFullYear()}</span><h1>{getMonthName(selectedDateValue, lang)}</h1><Button className={`month-calendar-button ${monthOpen ? "active" : ""}`} onClick={() => setMonthOpen(!monthOpen)} ariaLabel={getMonthName(selectedDateValue, lang)}><Icon name="calendar" size={18} /></Button></div>
        {monthOpen
          ? <MonthPicker t={t} monthDate={selectedDateValue} entries={filteredEntries} selectedDate={selectedDate} onSelect={(date) => { setSelectedDate(date); setMonthOpen(false); }} />
          : <TimelineCalendar t={t} dates={weekDates} entries={filteredEntries} selectedDate={selectedDate} onSelect={setSelectedDate} />}
      </section>
      <section className="surface-card day-sheet">
        <SectionHeader title={work ? t.workday : t.dayPlan} action={<span className="count-pill">{selectedEntries.length}</span>} />
        {selectedEntries.length ? <TaskList entries={selectedEntries} t={t} onToggle={onToggle} /> : <EmptyState>{t.noEntries}</EmptyState>}
      </section>
    </> : <TrackerDetails entries={filteredEntries} work={work} t={t} symbol={symbol} />}
    <Button className="fab" onClick={onCreate} ariaLabel={work ? t.addWork : t.createProcedure}><Icon name="plus" size={26} /></Button>
  </div>;
}

function TrackerDetails({ entries = [], work, t, symbol }: { entries: PlannerEntry[]; work: boolean; t: Copy; symbol: string }) {
  if (!entries.length) return <EmptyState>{t.noStatistics}</EmptyState>;
  const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
  return <section className="details-stack">
    <div className="big-number-card"><span>{work ? t.income : t.procedures}</span><strong>{work ? `${total.toLocaleString()} ${symbol}` : entries.length}</strong></div>
    {entries.map((entry, index) => <div className="list-card" key={entry.id}><span className={`soft-icon ${calendarTones[index % calendarTones.length]}`}><Icon name={entry.icon as IconName} /></span><div><strong>{entry.title}</strong><small>{entry.date}{entry.startTime ? ` · ${entry.startTime}` : ""}</small></div></div>)}
  </section>;
}

function CreateModal({ type, onClose, onSave, t, currency }: {
  type: EntryKind; onClose: () => void; onSave: (entry: NewPlannerEntry) => Promise<void>; t: Copy; currency: string;
}) {
  const [workType, setWorkType] = useState<"permanent" | "day" | "vacation" | "sick">("permanent");
  const [title, setTitle] = useState("");
  const [date, setDate] = useState(toDateKey(new Date()));
  const [startTime, setStartTime] = useState("");
  const [duration, setDuration] = useState("");
  const [icon, setIcon] = useState<IconName>(type === "work" ? "briefcase" : type === "beauty" ? "sparkle" : "check");
  const [amount, setAmount] = useState("");
  const [hours, setHours] = useState("");
  const [lunchFrom, setLunchFrom] = useState("");
  const [lunchTo, setLunchTo] = useState("");
  const [hourlyRate, setHourlyRate] = useState("");
  const [periodFrom, setPeriodFrom] = useState(date);
  const [periodTo, setPeriodTo] = useState(date);
  const [documentFile, setDocumentFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const symbol = getCurrencySymbol(currency);
  const heading = type === "work" ? t.addWork : type === "beauty" ? t.createProcedure : t.addTask;
  const workOptions = [
    ["permanent", t.permanent],
    ["day", t.oneDay],
    ["vacation", t.vacation],
    ["sick", t.sick],
  ] as const;
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setSaving(true);
    setError("");
    try {
      const isWork = type === "work";
      const workTitle = workType === "vacation" ? t.vacation : workType === "sick" ? t.sick : title.trim();
      const hoursValue = hours ? Number(hours) : 0;
      const rateValue = hourlyRate ? Number(hourlyRate) : 0;
      const workAmount = workType === "day" ? hoursValue * rateValue : amount ? Number(amount) : 0;
      const documentUrl = isWork && workType === "sick" && documentFile
        ? await uploadImage(documentFile)
        : undefined;
      await onSave({
        kind: type,
        title: isWork ? workTitle : title.trim(),
        date: isWork && (workType === "vacation" || workType === "sick") ? periodFrom : date,
        startTime: isWork && (workType === "vacation" || workType === "sick") ? "" : startTime,
        durationMinutes: isWork && (workType === "permanent" || workType === "day")
          ? (hoursValue ? hoursValue * 60 : null)
          : duration ? Number(duration) : null,
        icon,
        amount: isWork ? workAmount : amount ? Number(amount) : 0,
        ...(isWork ? {
          workType,
          ...(hoursValue ? { hours: hoursValue } : {}),
          ...(workType === "permanent" ? { lunchFrom, lunchTo } : {}),
          ...(workType === "day" && rateValue ? { hourlyRate: rateValue } : {}),
          ...(workType === "vacation" || workType === "sick" ? { periodFrom, periodTo } : {}),
          ...(documentUrl ? { documentUrl } : {}),
        } : {}),
      });
      onClose();
    } catch {
      setError(t.saveFailed);
    } finally {
      setSaving(false);
    }
  };
  return <div className="modal-backdrop" onMouseDown={onClose}><section className="modal-sheet" onMouseDown={(event) => event.stopPropagation()}>
    <div className="modal-handle" />
    <div className="modal-title"><div><span>{t.newEntry}</span><h2>{heading}</h2></div><Button className="icon-button" onClick={onClose} ariaLabel={t.close}><Icon name="close" /></Button></div>
    {type === "work" && <div className="type-grid">{workOptions.map(([id, label]) => <Button key={id} className={workType === id ? "active" : ""} onClick={() => setWorkType(id)}>{label}</Button>)}</div>}
    <form className="modal-form" onSubmit={submit}>
      {type !== "work" && <>
        <Field label={t.title} required value={title} onChange={setTitle} />
        <Field label={t.date} type="date" required value={date} onChange={setDate} />
        <div className="field-pair"><Field label={t.startTime} type="time" value={startTime} onChange={setStartTime} /><Field label={t.duration} type="number" value={duration} onChange={setDuration} /></div>
        {type === "beauty" && <Field label={`${t.amount}, ${symbol}`} type="number" value={amount} onChange={setAmount} />}
      </>}
      {type === "work" && (workType === "permanent" || workType === "day") && <>
        <Field label={t.title} required value={title} onChange={setTitle} />
        <Field label={t.date} type="date" required value={date} onChange={setDate} />
        <Field label={t.startTime} type="time" value={startTime} onChange={setStartTime} />
        <Field label={workType === "permanent" ? t.weeklyHours : t.hoursAmount} type="number" required value={hours} onChange={setHours} />
        {workType === "permanent"
          ? <><div className="field-pair"><Field label={t.lunchFrom} type="time" value={lunchFrom} onChange={setLunchFrom} /><Field label={t.lunchTo} type="time" value={lunchTo} onChange={setLunchTo} /></div><Field label={`${t.monthlySalary}, ${symbol}`} type="number" required value={amount} onChange={setAmount} /></>
          : <Field label={`${t.hourlyRate}, ${symbol}`} type="number" required value={hourlyRate} onChange={setHourlyRate} />}
      </>}
      {type === "work" && (workType === "vacation" || workType === "sick") && <>
        <div className="field-pair"><Field label={t.periodFrom} type="date" required value={periodFrom} onChange={setPeriodFrom} /><Field label={t.periodTo} type="date" required value={periodTo} onChange={setPeriodTo} /></div>
        {workType === "vacation"
          ? <Field label={`${t.vacationIncome}, ${symbol}`} type="number" required value={amount} onChange={setAmount} />
          : <label className="upload-field"><Icon name="camera" /><span><strong>{t.addPhoto}</strong><small>{documentFile?.name || t.document}</small></span><input type="file" accept="image/*" required onChange={(event) => setDocumentFile(event.target.files?.[0] ?? null)} /></label>}
      </>}
      <div className="icon-picker"><span>{t.icon}</span><div>{selectableIcons.map((item) => <Button key={item} className={icon === item ? "active" : ""} onClick={() => setIcon(item)} ariaLabel={item}><Icon name={item} size={18} /></Button>)}</div></div>
      {error && <p className="auth-error" role="alert">{error}</p>}
      <Button type="submit" className="primary-button" disabled={saving}>{saving ? `${t.loading}…` : t.save}</Button>
    </form>
  </section></div>;
}

const profilePhoto = "https://images.unsplash.com/photo-1574015974293-817f0ebebb74?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=1200";

function scaleHexColor(hex: string, amount: number) {
  const value = hex.replace("#", "");
  if (!/^[0-9A-Fa-f]{6}$/.test(value)) return hex;
  const channels = [0, 2, 4].map((offset) => Math.min(255, Math.round(Number.parseInt(value.slice(offset, offset + 2), 16) * amount)));
  return `#${channels.map((channel) => channel.toString(16).padStart(2, "0")).join("").toUpperCase()}`;
}

function Profile({ t, lang, setLang, accent, setAccent, firstName, setFirstName, miniPhoto, profileImage, currency, setCurrency, nickname, entries = [], pushState, onTogglePush, onUploadMiniPhoto, onUploadProfileImage, onUploadNavImage, onLogout }: {
  t: Copy; lang: Lang; setLang: (lang: Lang) => void; accent: string; setAccent: (color: string) => void;
  firstName: string; setFirstName: (value: string) => void; miniPhoto: string; profileImage: string;
  currency: string; setCurrency: (value: string) => void; nickname: string; entries: PlannerEntry[];
  pushState: PushState; onTogglePush: () => Promise<void>;
  onUploadMiniPhoto: (file: File) => Promise<void>; onUploadProfileImage: (file: File) => Promise<void>; onUploadNavImage: (file: File) => Promise<void>;
  onLogout: () => Promise<void>;
}) {
  const [settings, setSettings] = useState(false);
  const [baseAccent, setBaseAccent] = useState(accent);
  const [brightness, setBrightness] = useState(100);
  const [uploadError, setUploadError] = useState("");
  const updateAccent = (value: string) => {
    if (/^#[0-9A-Fa-f]{0,6}$/.test(value)) {
      setAccent(value);
      if (/^#[0-9A-Fa-f]{6}$/.test(value)) {
        setBaseAccent(value);
        setBrightness(100);
      }
    }
  };
  const chooseAccent = (value: string) => {
    setBaseAccent(value);
    setBrightness(100);
    setAccent(value.toUpperCase());
  };
  const changeBrightness = (value: number) => {
    setBrightness(value);
    setAccent(scaleHexColor(baseAccent, value / 100));
  };
  const runUpload = async (event: React.ChangeEvent<HTMLInputElement>, upload: (file: File) => Promise<void>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setUploadError("");
    try {
      await upload(file);
    } catch {
      setUploadError(t.photoUploadFailed);
    }
  };
  const validAccent = /^#[0-9A-Fa-f]{6}$/.test(accent) ? accent : "#FFFFFF";
  const beautyCount = entries.filter((entry) => entry.kind === "beauty").length;
  const activeDays = new Set(entries.map((entry) => entry.date)).size;
  const completion = entries.length ? Math.round(entries.filter((entry) => entry.completed).length / entries.length * 100) : 0;
  const pushDescription = pushState === "enabled"
    ? t.pushEnabled
    : pushState === "blocked"
      ? t.pushBlocked
      : pushState === "unsupported"
        ? t.pushUnsupported
        : t.pushDisabled;
  return <div className="profile-page">
    <img className="profile-photo" src={profileImage} alt="Portrait" /><div className="profile-gradient" />
    <header className="profile-top"><Button className="glass-button" onClick={() => setSettings(true)} ariaLabel={t.settings}><Icon name="settings" /></Button></header>
    <div className="profile-content"><h1><span>{firstName}</span><small className="name-mini-photo">{miniPhoto ? <img src={miniPhoto} alt="" /> : <Icon name="user" size={17} />}</small></h1><p>@{nickname}</p>
      <div className="profile-metrics"><div><strong>{beautyCount}</strong><span>{t.proceduresMetric}</span></div><div><strong>{activeDays}</strong><span>{t.rhythmDays}</span></div><div><strong>{completion}%</strong><span>{t.balance}</span></div></div>
    </div>
    {settings && <div className="settings-panel">
      <div className="modal-title"><div><span>{t.personalization}</span><h2>{t.settings}</h2></div><Button className="icon-button" onClick={() => setSettings(false)} ariaLabel={t.close}><Icon name="close" /></Button></div>
      <div className="setting-block name-fields"><Field label={t.firstName} value={firstName} onChange={setFirstName} /><label className="mini-photo-control"><span><strong>{t.miniPhoto}</strong><small>{t.miniPhotoHelp}</small></span><b>{miniPhoto ? <img src={miniPhoto} alt="" /> : <Icon name="camera" size={17} />}</b><input type="file" accept="image/*" onChange={(event) => runUpload(event, onUploadMiniPhoto)} /></label></div>
      <div className="setting-block setting-line"><div><strong>{t.language}</strong></div><LanguageToggle lang={lang} setLang={setLang} /></div>
      <div className="setting-block setting-line"><strong>{t.currency}</strong><select className="currency-select" value={currency} onChange={(event) => setCurrency(event.target.value)} aria-label={t.currency}><option value="RUB">RUB · ₽</option><option value="BYN">BYN · Br</option><option value="USD">USD · $</option><option value="EUR">EUR · €</option></select></div>
      <div className="setting-block notification-setting"><span><strong>{t.notifications}</strong><small>{pushDescription}</small></span><Button className={`notification-toggle ${pushState === "enabled" ? "active" : ""}`} disabled={pushState === "loading" || pushState === "blocked" || pushState === "unsupported"} onClick={() => onTogglePush().catch(() => setUploadError(t.pushFailed))}>{pushState === "loading" ? `${t.loading}…` : pushState === "enabled" ? t.disable : t.enable}</Button></div>
      <div className="setting-block"><strong>{t.accent}</strong><p>{t.accentHelp}</p><div className="hex-control"><input type="text" value={accent} maxLength={7} onChange={(event) => updateAccent(event.target.value)} aria-label={t.accent} /><label className="color-swatch" style={{ background: validAccent }} aria-label={t.accent}><input type="color" value={validAccent} onChange={(event) => chooseAccent(event.target.value)} /><span /></label></div><div className="brightness-control"><span>{t.darker}</span><input type="range" min="35" max="165" value={brightness} onChange={(event) => changeBrightness(Number(event.target.value))} aria-label={`${t.darker} — ${t.lighter}`} /><span>{t.lighter}</span></div></div>
      <label className="setting-block gallery-control"><span><strong>{t.profilePhoto}</strong><small>{t.profilePhotoHelp}</small></span><b className="camera-only"><Icon name="camera" size={19} /></b><input type="file" accept="image/*" onChange={(event) => runUpload(event, onUploadProfileImage)} /></label>
      <label className="setting-block gallery-control"><span><strong>{t.navPhoto}</strong><small>{t.navHelp}</small></span><b className="camera-only"><Icon name="camera" size={19} /></b><input type="file" accept="image/*" onChange={(event) => runUpload(event, onUploadNavImage)} /></label>
      <Button className="logout-button" onClick={() => onLogout().catch(() => setUploadError(t.authFailed))}>{t.logout}</Button>
      {uploadError && <p className="auth-error" role="alert">{uploadError}</p>}
    </div>}
  </div>;
}

function BottomNav({ active, setActive, image, t }: { active: string; setActive: (v: string) => void; image: string; t: Copy }) {
  const items = [
    { id: "home", label: t.homeLabel, icon: "home" as IconName }, { id: "beauty", label: t.beautyLabel, icon: "sparkle" as IconName },
    { id: "work", label: t.workLabel, icon: "briefcase" as IconName }, { id: "profile", label: t.profileLabel, icon: "settings" as IconName },
  ];
  const style = image ? { "--nav-image": `url("${image}")` } as CSSProperties : undefined;
  return <nav className={`bottom-nav ${image ? "with-image" : ""}`} style={style}>{items.map(item => <Button key={item.id} className={active === item.id ? "active" : ""} onClick={() => setActive(item.id)} ariaLabel={item.label}><span><Icon name={item.icon} /></span></Button>)}</nav>;
}

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [preferencesReady, setPreferencesReady] = useState(false);
  const [entries, setEntries] = useState<PlannerEntry[]>([]);
  const [dataError, setDataError] = useState("");
  const [lang, setLang] = useState<Lang>("ru");
  const [active, setActive] = useState("home");
  const [modal, setModal] = useState<EntryKind | null>(null);
  const [accent, setAccent] = useState("#FFFFFF");
  const [navImage, setNavImage] = useState("");
  const [firstName, setFirstName] = useState("Anna");
  const [miniPhoto, setMiniPhoto] = useState("");
  const [profileImage, setProfileImage] = useState(profilePhoto);
  const [currency, setCurrency] = useState("RUB");
  const [pushState, setPushState] = useState<PushState>("disabled");
  const t = dictionaries[lang];
  useEffect(() => listenToAuth((currentUser) => {
    setUser(currentUser);
    setAuthReady(true);
  }), []);

  useEffect(() => {
    if (!user) {
      setPushState("disabled");
      return;
    }
    getPushState(user.uid).then(setPushState).catch(() => setPushState("unsupported"));
  }, [user]);

  useEffect(() => {
    if (!user) return;
    let unsubscribe: (() => void) | undefined;
    listenToForegroundMessages((payload) => {
      if (Notification.permission !== "granted") return;
      navigator.serviceWorker.ready.then((registration) => registration.showNotification(
        payload.notification?.title || payload.data?.title || "Élan",
        {
          body: payload.notification?.body || payload.data?.body || "",
          data: { link: payload.fcmOptions?.link || payload.data?.link || "/" },
        },
      ));
    }).then((nextUnsubscribe) => {
      unsubscribe = nextUnsubscribe;
    });
    return () => unsubscribe?.();
  }, [user]);

  useEffect(() => {
    if (!user) {
      setEntries([]);
      setPreferencesReady(false);
      return;
    }

    let cancelled = false;
    let unsubscribeEntries: (() => void) | undefined;
    let unsubscribePreferences: (() => void) | undefined;
    const handleError = () => setDataError(t.saveFailed);
    verifyFirestoreAvailability(user.uid).then(() => {
      if (cancelled) return;
      unsubscribeEntries = subscribeToEntries(user.uid, (nextEntries) => {
        setEntries(Array.isArray(nextEntries) ? nextEntries : []);
        setDataError("");
      }, handleError);
      unsubscribePreferences = subscribeToUserPreferences(user.uid, (preferences) => {
        if (preferences.lang) setLang(preferences.lang);
        if (preferences.accent) setAccent(preferences.accent);
        if (preferences.currency) setCurrency(preferences.currency);
        if (preferences.firstName !== undefined) setFirstName(preferences.firstName);
        if (preferences.navImage !== undefined) setNavImage(preferences.navImage);
        if (preferences.miniPhoto !== undefined) setMiniPhoto(preferences.miniPhoto);
        if (preferences.profileImage) setProfileImage(preferences.profileImage);
        setPreferencesReady(true);
      }, handleError);
    }).catch((error: unknown) => {
      if (cancelled) return;
      const code = typeof error === "object" && error !== null && "code" in error ? String(error.code) : "";
      setEntries([]);
      setPreferencesReady(false);
      setDataError(code === "permission-denied" ? t.rulesUnavailable : t.databaseUnavailable);
    });

    return () => {
      cancelled = true;
      unsubscribeEntries?.();
      unsubscribePreferences?.();
    };
  }, [user]);

  useEffect(() => {
    if (!user || !preferencesReady) return;
    const timeout = window.setTimeout(() => {
      saveUserPreferences(user.uid, {
        lang,
        accent,
        currency,
        firstName,
        navImage,
        miniPhoto,
        profileImage,
      }).catch(() => setDataError(t.saveFailed));
    }, 500);
    return () => window.clearTimeout(timeout);
  }, [accent, currency, firstName, lang, miniPhoto, navImage, preferencesReady, profileImage, user]);

  const toggleEntry = (entry: PlannerEntry) => {
    if (!user) return;
    setEntryCompleted(user.uid, entry.id, !entry.completed).catch(() => setDataError(t.saveFailed));
  };
  const saveEntry = async (entry: NewPlannerEntry) => {
    if (!user) throw new Error("Authentication required");
    await addPlannerEntry(user.uid, entry);
  };
  const uploadProfileFile = async (target: "mini" | "profile" | "navigation", file: File) => {
    if (!user) throw new Error("Authentication required");
    const url = await uploadImage(file);
    if (target === "mini") setMiniPhoto(url);
    if (target === "profile") setProfileImage(url);
    if (target === "navigation") setNavImage(url);
  };
  const togglePushNotifications = async () => {
    if (!user) return;
    const wasEnabled = pushState === "enabled";
    setPushState("loading");
    try {
      if (wasEnabled) {
        await disablePushNotifications(user.uid);
        setPushState("disabled");
      } else {
        await enablePushNotifications(user.uid);
        setPushState("enabled");
      }
    } catch (error) {
      setPushState(await getPushState(user.uid));
      throw error;
    }
  };

  let page: ReactNode;
  if (active === "home") {
    page = <Home t={t} lang={lang} currency={currency} entries={entries} onCreate={() => setModal("task")} onToggle={toggleEntry} />;
  } else if (active === "beauty") {
    page = <Tracker type="beauty" t={t} lang={lang} currency={currency} entries={entries} onCreate={() => setModal("beauty")} onToggle={toggleEntry} />;
  } else if (active === "work") {
    page = <Tracker type="work" t={t} lang={lang} currency={currency} entries={entries} onCreate={() => setModal("work")} onToggle={toggleEntry} />;
  } else {
    page = <Profile t={t} lang={lang} setLang={setLang} accent={accent} setAccent={setAccent} firstName={firstName} setFirstName={setFirstName} miniPhoto={miniPhoto} profileImage={profileImage} currency={currency} setCurrency={setCurrency} nickname={user?.email?.split("@")[0] ?? ""} entries={entries} pushState={pushState} onTogglePush={togglePushNotifications} onUploadMiniPhoto={(file) => uploadProfileFile("mini", file)} onUploadProfileImage={(file) => uploadProfileFile("profile", file)} onUploadNavImage={(file) => uploadProfileFile("navigation", file)} onLogout={logoutUser} />;
  }

  if (!authReady) return <main className="auth-shell"><span className="auth-loading">{t.loading}…</span></main>;
  if (!user) return <Auth onAuthenticate={(mode, nickname, password) => mode === "login" ? loginWithNickname(nickname, password).then(() => undefined) : signUpWithNickname(nickname, password).then(() => undefined)} lang={lang} setLang={setLang} />;
  const validAccent = /^#[0-9A-Fa-f]{6}$/.test(accent) ? accent : "#FFFFFF";
  const accentChannels = [1, 3, 5].map((offset) => Number.parseInt(validAccent.slice(offset, offset + 2), 16) / 255);
  const accentLuminance = accentChannels
    .map((channel) => channel <= 0.03928 ? channel / 12.92 : ((channel + 0.055) / 1.055) ** 2.4)
    .reduce((sum, channel, index) => sum + channel * [0.2126, 0.7152, 0.0722][index], 0);
  const accentForeground = accentLuminance > 0.179 ? "#000000" : "#FFFFFF";
  return <main className={`app-shell ${active === "profile" ? "profile-active" : ""}`} style={{ "--accent": validAccent, "--accent-foreground": accentForeground } as CSSProperties}>
    {dataError && <div className="data-error" role="alert">{dataError}</div>}
    <div className="app-content">{page}</div>
    <BottomNav active={active} setActive={setActive} image={navImage} t={t} />
    {modal && <CreateModal type={modal} t={t} currency={currency} onSave={saveEntry} onClose={() => setModal(null)} />}
  </main>;
}
