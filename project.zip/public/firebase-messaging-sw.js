importScripts("https://www.gstatic.com/firebasejs/12.19.0/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/12.19.0/firebase-messaging-compat.js");

firebase.initializeApp({
  apiKey: "AIzaSyBvaXt5YgXB5SBFNKsxFf-m-WRMCiHV1rM",
  authDomain: "planer-20a24.firebaseapp.com",
  projectId: "planer-20a24",
  messagingSenderId: "24354921057",
  appId: "1:24354921057:web:bee678818a7dea53b2e820",
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
  if (payload.notification) return;
  const title = payload.notification?.title || payload.data?.title || "Élan";
  const options = {
    body: payload.notification?.body || payload.data?.body || "",
    data: {
      link: payload.fcmOptions?.link || payload.data?.link || "/",
    },
  };

  self.registration.showNotification(title, options);
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const link = event.notification.data?.link || "/";
  event.waitUntil(
    clients.matchAll({ type: "window", includeUncontrolled: true }).then((windows) => {
      const existingWindow = windows.find((windowClient) => windowClient.url.startsWith(self.location.origin));
      if (existingWindow) {
        existingWindow.navigate(link);
        return existingWindow.focus();
      }
      return clients.openWindow(link);
    }),
  );
});
